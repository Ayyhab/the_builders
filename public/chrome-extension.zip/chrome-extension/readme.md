1. navigate to chrome://extensions/

2. activate developer mode in the top right corner

3. press load unpacked in the top left

4. navigate to the folder called chrome-extension

5. navigate to the subfolder called extensions, press ok

6. good to go!
